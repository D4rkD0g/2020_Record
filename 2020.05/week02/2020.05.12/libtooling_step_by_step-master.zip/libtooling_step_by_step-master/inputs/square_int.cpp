int square_int(int num)
{
	return num*num;
}
