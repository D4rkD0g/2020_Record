#include <iostream>

void print_int(int val)
{
	std::cout << val << std::endl;
}