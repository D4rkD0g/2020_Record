#define MY_FUNC theFunction

bool MY_FUNC()
{
	return true;
}
